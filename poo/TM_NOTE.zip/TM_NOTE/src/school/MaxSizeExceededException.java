package school;

public class MaxSizeExceededException{
    
}