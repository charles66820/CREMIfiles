package school;

public class MusicSchool{
	
}