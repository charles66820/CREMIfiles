#include <stdlib.h>

int a = 1;
int main(void) {
  return EXIT_SUCCESS;
}
