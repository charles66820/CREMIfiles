#include <stdlib.h>

int a = 1;
int main(void) {
  int b = 0;
  return EXIT_SUCCESS;
}
