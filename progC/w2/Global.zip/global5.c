#include <stdlib.h>

int a;
int main(void) {
  int b = 0;
  return EXIT_SUCCESS;
}
