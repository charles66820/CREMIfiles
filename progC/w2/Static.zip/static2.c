#include <stdlib.h>

int main(void) {
  static int a;
  return EXIT_SUCCESS;
}
