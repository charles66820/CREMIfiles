#include <stdlib.h>

int main(void) {
  static int a = 1;
  return EXIT_SUCCESS;
}
