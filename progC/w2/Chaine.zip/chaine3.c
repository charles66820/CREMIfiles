#include <stdlib.h>

int main(void) {
  char s3[] = {'H','e','l','l','o',' ','W','o','r','l','\0'};
  return EXIT_SUCCESS;
}
