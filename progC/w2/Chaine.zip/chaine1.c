#include <stdlib.h>

int main(void) {
  char* s1 = "Hello Worl";
  return EXIT_SUCCESS;
}
