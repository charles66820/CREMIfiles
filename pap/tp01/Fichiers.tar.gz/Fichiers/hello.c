#include <stdio.h>

int main()
{

   printf("Bonjour !\n");
   printf("Au revoir !\n");

  return 0;
}
