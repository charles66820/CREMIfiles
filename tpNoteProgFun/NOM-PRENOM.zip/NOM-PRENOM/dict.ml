(* Exercice 5 *)
(* 6. *)
(*** let dict_adds couples dict = ***)

(* Exercice 6 *)
(* 7. *)
(*** let make_dict couples = ***)

(* Exercice 7 *)
(* 8. *)
(*** let find_word word dict = ***)

(* Exercice 8 *)
(* 9. *)
(*** let translate words dict = ***)

