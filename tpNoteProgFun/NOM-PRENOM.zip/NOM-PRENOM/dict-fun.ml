(* Implementation avec fonctions *)
(* Exercice 9 *)
(* 10 *)
(*** type ... dict = ... ***)

(* 11. *)
(*** let dict_empty = ***)

(* 12 *)
(*** let dict_add key value = ***)

(* 13 *)			      
(*** let dict_find key dict = ***)

(* 14 *)
(*** let dict_remove key dict = ***)
