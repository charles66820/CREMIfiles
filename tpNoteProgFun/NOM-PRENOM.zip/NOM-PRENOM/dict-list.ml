(* Implementation avec listes *)
(* Exercice 1 *)
(* 1. *)
(*** type ... dict = ... ***)

(* 2. *)			       
(*** let dict_empty = ***)

(* Exercice 2 *)
(* 3. *)
(*** let dict_add key value = ***)

(* Exercice 3 *)
(* 4. *)
(*** let dict_find key dict = ***)

(* Exercice 4 *)						       
(* 5. *)
(*** let dict_remove key dict = ***)

