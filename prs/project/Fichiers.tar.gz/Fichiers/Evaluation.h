#ifndef _EVALUATION_H
#define _EVALUATION_H

#include "Shell.h"

extern int evaluer_expr(Expression *e);

#endif
