"""Complete example of use of the simulator.

To run, use 'python3 complete_example.py'.

This example uses two schedulers for two different scenarios:
    - The round-robin scheduler is used to schedule 5 tasks over
    3 resources. The tasks have exponentially larger loads.
    An analysis of the schedule is presented.
    - The list scheduler is used to schedule 20 tasks over
    4 resources. The tasks have loads taken from a uniform
    distribution. An analysis of the schedule is presented
    and plotted.
"""

import itertools
import math

import simulator.schedulers as schedulers
import simulator.support as support


def exp1(num_tasks = 20, num_resources = 4):
    task_loads = support.generate_uniform_loads(num_tasks, 1, 5, 99)

    print("Scenario 1: round-robin scheduler")
    # Calls the scheduler
    mapping = schedulers.round_robin(num_tasks, num_resources, True)
    # Presents an analysis of the results
    support.evaluate_mapping(mapping, task_loads, num_resources)
    # Plots the resulting mapping and saves it to a file
    support.plot_mapping(mapping, task_loads, num_resources, 'scenario_round_robin_T' + str(num_tasks) + '_R' + str(num_resources) + '.png')

    print("\nScenario 2: list scheduler")
    mapping = schedulers.list_scheduler(task_loads, num_resources)
    support.evaluate_mapping(mapping, task_loads, num_resources)
    support.plot_mapping(mapping, task_loads, num_resources, 'scenario_list_scheduler_T' + str(num_tasks) + '_R' + str(num_resources) + '.png')

    print("\nScenario 3: compact")
    mapping = schedulers.compact(num_tasks, num_resources)
    support.evaluate_mapping(mapping, task_loads, num_resources)
    support.plot_mapping(mapping, task_loads, num_resources, 'scenario_compact_T' + str(num_tasks) + '_R' + str(num_resources) + '.png')

    print("\nScenario 4: uniformly random")
    mapping = schedulers.uniformly_random(num_tasks, num_resources)
    support.evaluate_mapping(mapping, task_loads, num_resources)
    support.plot_mapping(mapping, task_loads, num_resources, 'scenario_uniformly_random_T' + str(num_tasks) + '_R' + str(num_resources) + '.png')

# exp1(20, 4)
# exp1(200, 4)
# exp1(20, 16)
# exp1(200, 16)

def exp4(num_tasks = 20, num_resources = 4):
    task_loads = support.generate_uniform_loads(num_tasks, 1, 5, 99)

    print("\nScenario 5: lpt")
    mapping = schedulers.lpt(task_loads, num_resources)
    support.evaluate_mapping(mapping, task_loads, num_resources)
    support.plot_mapping(mapping, task_loads, num_resources, 'scenario_lpt_T' + str(num_tasks) + '_R' + str(num_resources) + '.png')

# exp4(20, 4)
# exp4(200, 4)
# exp4(20, 16)
# exp4(200, 16)

def exp6(num_tasks = 20, num_resources = 4, makespan = 0):
    task_loads = support.generate_uniform_loads(num_tasks, 1, 5, 99)

    print("\nScenario 6: lpt_with_limits")
    mapping = schedulers.lpt_with_limits(task_loads, num_resources, makespan)
    support.evaluate_mapping(mapping, task_loads, num_resources)
    support.plot_mapping(mapping, task_loads, num_resources, 'scenario_lpt_with_limits_T' + str(num_tasks) + '_R' + str(num_resources) + '.png')

# for i in range(8, 0, -1):
#     print("makespan : " + str(i))
#     exp4(20, 4)
#     exp6(20, 4, i)
#     exp4(20, 16)
#     exp6(20, 16, i)

# for i in range(60, 0, -1):
#     exp4(200, 4)
#     exp6(200, 4, i)
#     exp4(200, 16)
#     exp6(200, 16, i)

def exp8(num_tasks = 20, num_resources = 4, resource_speeds = None):
    task_loads = support.generate_uniform_loads(num_tasks, 1, 5, 99)

    print("\nScenario 7: list_scheduler_for_uniform_resources")
    mapping = schedulers.list_scheduler_for_uniform_resources(task_loads, num_resources, resource_speeds)
    support.evaluate_mapping(mapping, task_loads, num_resources)
    support.plot_mapping(mapping, task_loads, num_resources, 'scenario_list_scheduler_for_uniform_resources_T' + str(num_tasks) + '_R' + str(num_resources) + '.png')


exp8(200, 4, [8, 8, 4, 4])
