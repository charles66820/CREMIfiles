import itertools

import simulator.schedulers as schedulers
import simulator.support as support

def computeMakespan(num_tasks, task_loads):
    # C_{max}
    perm1 = []
    for i in range(num_tasks + 1):
        for j in itertools.combinations(task_loads, r=i):
            perm1.append(list(j))

    perm2 = list(perm1)
    perm2.reverse()

    maxTime = []

    for i in range(len(perm1)):
        sum1 = sum(perm1[i])
        sum2 = sum(perm2[i])
        maxTime.append(max(sum1, sum2))

    # The min C_{max}
    makespan = min(maxTime)
    return makespan

def exo3():
    num_tasks = 8
    num_resources = 2

    # 12, 81 : [14, 10] ; 73 : [13, 9] ; 78 : [12, 8]
    task_loads = support.generate_uniform_loads(num_tasks, 1, 5, 12)

    print("\nScenario : list scheduler")

    calOpt=(2-1/num_resources)
    print("(2-1/m) = " + str(calOpt))
    makespan = computeMakespan(num_tasks, task_loads)
    print("makespan × (2-1/m) = " + str(makespan * calOpt))

    mapping = schedulers.list_scheduler(task_loads, num_resources)
    support.evaluate_mapping(mapping, task_loads, num_resources)
    support.plot_mapping(mapping, task_loads, num_resources, 'adversary_scenario_list_scheduler.png')

    mapping = schedulers.lpt(task_loads, num_resources)
    support.evaluate_mapping(mapping, task_loads, num_resources)
    support.plot_mapping(mapping, task_loads, num_resources, 'adversary_scenario_lpt.png')

def exo7():
    def run(num_tasks = 8):
        num_resources = 3

        task_loads = support.generate_uniform_loads(num_tasks, 1, 5, 99)

        print("\nScenario : lpt")

        calOpt=(4/3 - 1/3*num_resources)
        print("(4/3 - 1/3×m) = " + str(calOpt))

        mapping = schedulers.lpt(task_loads, num_resources)
        support.evaluate_mapping(mapping, task_loads, num_resources)
        support.plot_mapping(mapping, task_loads, num_resources, 'adversary_scenario_lpt_T' + str(num_tasks) + '.png')

    for n in range(1, 256):
        run(n)

exo3()
exo7()
