#include "foo.h"

int foo_1() {
	return 5;
}

int foo_2() {
	return -4;
}