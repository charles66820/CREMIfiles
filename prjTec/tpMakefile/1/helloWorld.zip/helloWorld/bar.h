#ifndef _BAR_H_
#define _BAR_H_

double bar(double x);

#endif