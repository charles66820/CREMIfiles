#ifndef _FOO_H_
#define _FOO_H_

int foo_1();
int foo_2();

#endif