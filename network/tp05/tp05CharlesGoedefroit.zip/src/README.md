# mini site

## RUN

Pour que le suite fonctione plainement avec le PHP metter ce site sut un serveur qui execute le PHP.

Ou

Si vous avez PHP installer sur votre machine vous pouvez faire la commande :

```bash
cd src
php -S localhost:8000
```
