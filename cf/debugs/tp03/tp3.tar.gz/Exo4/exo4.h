#include "limits.h"

/*Mettre la spécification ici.
*/
int max_element(const int* t, int n);

/*Mettre la spécification ici.
*/
void sum_of_tab(int *a, int *b, int n);