#include "unsigned_overflow.h"

unsigned int add(unsigned int a, unsigned int b){
	return a + b;
}

unsigned int sub(unsigned int a, unsigned int b){
	return a - b;
}