
/*@ ensures \result == a + b;
*/
unsigned int add(unsigned int a, unsigned int b);

/*@ ensures \result == a - b;
*/
unsigned int sub(unsigned int a, unsigned int b);
