#include "set_to_zero.h"

void set_to_zero(int *tab, int n)
{
	for (int i = 0; i < n; i++)
	{
		tab[i] = 0;
	}
}