#include "limits.h"

/* Écrivez ici votre spécification. Attention, elle doit permettre de prouver les assertions RTE.*/
int f(int a,int b,int x);