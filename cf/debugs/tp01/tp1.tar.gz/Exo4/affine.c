#include "affine.h"

int f(int a, int b, int x)
{
  return a * x + b;
}