
/*@ ensures \result >= 0;
*/
int plus_one(int a);