#include "plus_one.h"

int plus_one(int a)
{
	return a + 1;
}