#include "max.h"
#include "limits.h"

int max(int a, int b)
{
	return INT_MAX;
}