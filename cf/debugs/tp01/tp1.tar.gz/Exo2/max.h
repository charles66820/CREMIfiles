
/*Put your specification here.
*/
int max(int a, int b);