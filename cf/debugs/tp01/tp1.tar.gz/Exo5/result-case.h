
/* Put your specification here.
*/
int caseResult(int a, int b, int c);