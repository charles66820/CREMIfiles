#include "exo2.h"

void sort_ptr(int *a, int *b){
	*a = INT_MIN;
	*b = INT_MAX;
}