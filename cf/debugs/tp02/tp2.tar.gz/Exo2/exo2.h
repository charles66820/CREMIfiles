#include "limits.h"

/* Mettez votre spécification ici.*/
void sort_ptr(int* a, int* b);

/* Mettez votre spécification ici. Attention, on demande de plus que la valeur de *b ne soit pas modifiée.*/
void sum_in_pointer(int* a, int* b);