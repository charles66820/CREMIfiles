
/* Mettez votre spécification ici.*/
int max_ptr(int *a, int *b);

/* Mettez votre spécification ici.*/
int sum_first_last(int *a, int n);

/* Mettez votre spécification ici.*/
void swap_first_last(int *a, int n);

/* Mettez votre spécification ici.*/
void swap(int *a, int *b);